package edu.ufl.cise.plpfa21.assignment3.ast;

public interface IDeclaration extends IASTNode {

	void setType(IType type);
	IType getType();
}
