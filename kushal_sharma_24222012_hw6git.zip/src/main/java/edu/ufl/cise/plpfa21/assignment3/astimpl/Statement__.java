package edu.ufl.cise.plpfa21.assignment3.astimpl;

public abstract class Statement__ extends ASTNode__ {

	public Statement__(int line, int posInLine, String text) {
		super(line, posInLine, text);
	}

}
